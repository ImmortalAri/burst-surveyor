# Burst Surveyor v0.2.0 blind timing comparison

Each of the 780 pulse designs was sampled on the recorded channel grid of a CHIME/FRB Catalog 2 intensity noise background. The paired default bounded fits used identical pixels. One fit received the recorded time offsets and the other used a shared time grid. The protocol and input manifest were frozen before fitting.

`results-summary.json` gives endpoint counts, discordant pairs, paired 95% intervals and on-pulse error. `paired-results.csv` contains one row per injection. For an injected single, an outcome of 1 means a false split. For an injected pair, 1 means both arrivals were recovered. All assigned cases enter those rates. The on-pulse errors use exported fits only. Time coordinates in the CSV are relative to the crop on the 600 MHz reference grid.

`hosts.json` identifies the 130 original public intensity files, their SHA-256 digests, zero-based crop starts and retained rows in the 1,024-channel subset. `designs.json` contains the frozen physical pulse parameters and strengths. `truth.json` contains the scoring targets. See `PROTOCOL.md` for background selection, timing, normalization and scoring. The observational data are from the [CHIME/FRB Catalog 2 release](https://chime-frb.ca/catalogs/catalog2).

The first measured run reported a worker timeout on one input. That input was fitted in isolation, then the complete measured run was repeated on the sealed inputs. `repeat-check.json` records the cross-checks and the run digests.

## Reproduce the fits

Unpack the archive in an empty directory. Use CPython 3.12 and install the released v0.2.0 wheels and constraints. The preparation script uses h5py 3.16.0. The public data files are downloaded once and checked against the archived digests. [Release installation instructions](https://github.com/ImmortalAri/burst-surveyor/blob/v0.2.0/docs/guide.md#installation)

```sh
python -m pip install h5py==3.16.0
python fetch_products.py hdf5
python prepare.py generate --out . --h5 hdf5
python check_inputs.py .
for arm in shared measured
do
    burstsurveyor fit "$arm/inputs" "$arm/run" --mode bounded --workers 3 || exit 1
    burstsurveyor verify "$arm/run" > "$arm/verified.json" || exit 1
done
python score.py .
```

`SHA256SUMS` records the distributed files. After input generation, compare the SHA-256 digests of `seal.json` and `input-manifest.json` against that list. Run manifests contain timestamps, so new runs have their own digests. The original release wheels have the following SHA-256 digests.

| Wheel | SHA-256 |
| --- | --- |
| burst-surveyor 0.2.0 | `9cd1328129922a42d69c6890be0923a56cd34e1c6d2c16d6a33898d5c1d4302a` |
| fitburst 0.1.0 | `c7dde071fbdfb556a1755f928c5ebe80ef4f558f013e6979faf0ae43d9d9adc3` |
