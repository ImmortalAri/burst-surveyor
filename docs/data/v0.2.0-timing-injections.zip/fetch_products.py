"""Download and verify the 130 public CHIME/FRB Catalog 2 intensity products."""
import argparse
import hashlib
import json
from pathlib import Path
from shutil import copyfileobj
from urllib.request import urlopen


BASE = "https://cadc-west-01.canfar.net/vault/files/AstroDataCitationDOI/CISTI.CANFAR/25.0066/data/dynamic_spectra/data"


def digest(path):
    with path.open("rb") as data:
        return hashlib.file_digest(data, "sha256").hexdigest()


def fetch(folder, hosts):
    folder.mkdir(parents=True, exist_ok=True)
    for host in sorted(hosts, key=lambda h: h["product"]):
        name, checksum = host["product"], host["product_sha256"]
        target = folder / name
        if target.is_file() and digest(target) == checksum:
            continue
        temp = target.with_suffix(".part")
        with urlopen(f"{BASE}/{name}", timeout=120) as reply, temp.open("wb") as out:
            copyfileobj(reply, out)
        if digest(temp) != checksum:
            raise ValueError(f"Catalog product SHA-256 mismatch for {name}")
        temp.replace(target)
        print(name, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    fetch(args.folder, json.loads(Path(__file__).with_name("hosts.json").read_bytes()))
