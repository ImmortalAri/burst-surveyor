"""Check the prefit seal, equal pixels and absence of truth fields in the input directories."""
import hashlib
import json
from collections import Counter
from pathlib import Path
from zipfile import ZipFile
import argparse


def sha(stream):
    return hashlib.file_digest(stream, "sha256").hexdigest()


def checked(path, expected):
    with path.open("rb") as f:
        assert sha(f) == expected, path


def verify(root):
    for name, expected in json.loads((root / "seal.json").read_bytes()).items():
        checked(root / name, expected)
    manifest = json.loads((root / "input-manifest.json").read_bytes())
    truth = json.loads((root / "truth.json").read_bytes())
    assert truth.keys() == manifest.keys() and len(truth) == 780
    assert Counter(len(t["arrival_bins"]) for t in truth.values()) == {1: 260, 2: 520}
    dirs = {arm: root / arm / "inputs" for arm in ("measured", "shared")}
    for folder in dirs.values():
        assert {p.name for p in folder.iterdir()} == {key + ".npz" for key in truth}
    host_digests = {}
    for case, expected in manifest.items():
        paths = {arm: folder / (case + ".npz") for arm, folder in dirs.items()}
        for arm, path in paths.items():
            checked(path, expected[arm])
        with ZipFile(paths["measured"]) as measured, ZipFile(paths["shared"]) as shared:
            assert set(shared.namelist()) == {"data_full.npy", "metadata.npy"}
            assert set(measured.namelist()) == set(shared.namelist()) | {"channel_time_offset_s.npy"}
            for member in shared.namelist():
                assert shared.read(member) == measured.read(member)
            d = hashlib.sha256(measured.read("channel_time_offset_s.npy")).hexdigest()
            assert host_digests.setdefault(truth[case]["event"], d) == d
    assert len(host_digests) == len(set(host_digests.values())) == 130
    print("Verified prefit seal, 780 identical intensity and metadata pairs, 130 distinct offset vectors.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    verify(parser.parse_args().root)
