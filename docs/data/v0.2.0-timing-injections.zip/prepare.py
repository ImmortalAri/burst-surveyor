"""Select genuine recorded noise and produce paired, sealed v0.2.0 blind inputs."""
import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

import h5py
import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.special import ndtr
from scipy.stats import exponnorm
from burstsurveyor.science.objective import reporting_noise


SEED = "catalog2-timing-injections-20261123"
CROP = 70
GUARD = 3
STRIDE = 16
FIRST = 8
N_HOSTS = 130
INPUT_SEAL = "826db297b678bdc9cdd98c16cb4a29ca3e8f76b37e96dd599db4ac27421e2bf0"
WHEEL_SHA = "9cd1328129922a42d69c6890be0923a56cd34e1c6d2c16d6a33898d5c1d4302a"
FITTER_SHA = "c7dde071fbdfb556a1755f928c5ebe80ef4f558f013e6979faf0ae43d9d9adc3"


def order(label, token):
    return hashlib.sha256(f"{SEED}:{label}:{token}".encode()).hexdigest()


def digest(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    tmp.replace(path)


def islands(off):
    idx = np.flatnonzero(off)
    return sorted(np.split(idx, np.flatnonzero(np.diff(idx) > 1) + 1), key=len, reverse=True)


def open_native(path, event):
    with h5py.File(path) as f:
        a = f.attrs
        assert str(a["event_id"]) == event and a["is_dedispersed"] and a["stokes"] == "I"
        dt, df = float(a["res_time"]), float(a["res_freq"])
        freq = f["index_map/freqs"][:]
        times = f["index_map/times"][:]
        assert len(freq) == 16384 and abs(dt / 0.00098304 - 1) < 1e-3
        np.testing.assert_allclose(freq, freq[0] + df * np.arange(len(freq)), atol=1e-9, rtol=0)
        good = f["good_freq"][:] & f["flag"][:].all(axis=1)
        pick = np.arange(FIRST, len(freq), STRIDE)
        delay = a["dm_const"] * a["dm_incoherent"] * (freq ** a["dm_index"] - a["ref_freq"] ** a["dm_index"])
        mid = len(times) // 2
        residual = (f["times"][:, mid] - times[mid]) - delay
        origin = float(np.median(residual[good]))
        phases = residual[pick] - origin
        stamps = f["times"][FIRST::STRIDE, :]
        actual = ((stamps - times[0]) - delay[pick, None]) - origin
        err = float(np.max(np.abs(actual[good[pick]] - (dt * np.arange(len(times)) + phases[good[pick], None]))) / dt)
        assert np.isfinite(err) and err <= 0.025
        phases[~np.isfinite(phases) & ~good[pick]] = 0
        assert np.isfinite(phases).all()
        raw = f["data"][FIRST::STRIDE, :]
        raw[~good[pick]] = 0
        freq_selected = freq[pick]
        grid = dict(res_time=dt, res_freq=STRIDE * df, freqs_bin0=float(freq_selected[0] - 0.5 * STRIDE * df),
                    times_bin0=float(a["times_bin0"]), is_dedispersed=True)
        return raw, grid, freq_selected, phases, err


def find_crop(raw, full_off):
    ids, var, _, off_bins, uncertain = reporting_noise(raw)
    valid = np.zeros(raw.shape[1], bool)
    valid[off_bins] = True
    off = np.flatnonzero(valid & full_off)
    spans = [i for i in islands(valid & full_off) if len(i) >= CROP + 2 * GUARD]
    if not spans or uncertain or len(ids) < .30 * len(raw):
        return None
    excursion = np.zeros(raw.shape[1])
    for band in [ids, *np.array_split(ids, 4)]:
        centered = raw[band].astype(float) - np.median(raw[np.ix_(band, off)], axis=1, keepdims=True)
        profile = (centered / np.sqrt(var[band, None])).sum(axis=0)
        for width in (0, 1, 2, 4):
            z = gaussian_filter1d(profile, width) if width else profile
            midpoint = np.median(z[off])
            mad = max(1e-12, 1.4826 * np.median(abs(z[off] - midpoint)))
            excursion = np.maximum(excursion, abs(z - midpoint) / mad)
    for span in spans:
        start = int(span[0] + (len(span) - CROP) // 2)
        stop = start + CROP
        high = float(excursion[start - GUARD:stop + GUARD].max())
        if high > 8.0:
            continue
        y = raw[ids, start:stop]
        keep = ids[np.isfinite(y).all(axis=1) & (np.std(y, axis=1) > 0)]
        if len(keep) >= 0.30 * len(raw):
            return start, keep, high
    return None


def select(args):
    atlas = args.atlas
    rows = {r["event_id"]: r for r in csv.DictReader((atlas / "paired-results.csv").open())}
    old = args.study / "run"
    assert digest(old / "blind/seal.json") == INPUT_SEAL
    for name, expected in read(old / "blind/seal.json").items():
        assert digest(old / "blind" / name) == expected
    sources = {}
    for r in csv.DictReader((args.study / "catalog2-20251231.csv").open()):
        name = (r["repeater_name"] or r["tns_name"]).strip()
        if r["event_id"] in sources:
            assert sources[r["event_id"]] == name
        sources[r["event_id"]] = name
    training_ids = {r["calibration_group"] for r in read(old / "blind/design.json")["calibration_proxy_rows"]}
    used = {s for r in read(old / "development/allocated.json") if r["group"] in training_ids
            for s in r["catalog_sources"]}
    assert used
    local = {}
    for location in args.h5:
        local.update({p.stem: p for p in location.glob("*.h5") if p.stem.isdecimal()})
    chosen, screen = [], {}
    for event in sorted(local.keys() & rows.keys(), key=lambda e: order("screen", e)):
        r = rows[event]
        name = sources.get(event)
        if (r["timing"] != "recorded" or not r["prediction"] or r["frequency_bin_factor"] != "1"
                or not name or name in used or json.loads(r["shape"])[0] != 16384
                or abs(float(r["dt_ms"]) / .98304 - 1) >= .001):
            screen[event] = "source or grid ineligible"
            continue
        with np.load(atlas / r["prediction"], allow_pickle=False) as saved:
            full_off = saved["offburst_time_mask"]
            if len(islands(full_off)[0]) < CROP + 2 * GUARD:
                screen[event] = "full-resolution off-burst window too short"
                continue
            expected_phases = saved["channel_time_offset_s"][FIRST::STRIDE]
            expected_freq = saved["frequency"][FIRST::STRIDE]
        path = local[event]
        assert digest(path) == r["product_sha256"]
        raw, grid, freq, phases, err = open_native(path, event)
        np.testing.assert_allclose(phases, expected_phases, atol=1e-15, rtol=1e-12)
        np.testing.assert_allclose(freq, expected_freq, atol=1e-10, rtol=0)
        crop = find_crop(raw, full_off)
        if crop is None:
            screen[event] = "crop screen"
            continue
        start, ids, high = crop
        chosen.append(dict(event=event, tns=r["tns_name"], source=name, product=r["product_filename"],
                           product_sha256=r["product_sha256"], start=start, channels=ids.tolist(),
                           phase_span_bins=float(np.ptp(phases[ids]) / grid["res_time"]),
                           timestamp_error_bins=err, max_guard_excursion=high))
        used.add(name)
        screen[event] = "included"
        if len(chosen) == N_HOSTS:
            break
    print("Sources selected", len(chosen), dict(Counter(screen.values())), flush=True)
    write(args.out / "screen.json", screen)
    if len(chosen) != N_HOSTS:
        raise ValueError("Insufficient local eligible sources. Extend the HDF5 pool before fitting.")
    truth = read(old / "blind/truth.json")
    original = defaultdict(dict)
    for item in read(old / "blind/manifest.json"):
        key = item["case"]
        if truth[key]["suite"] == "BaseCat 2-like":
            original[item["host_group"]][key] = truth[key]
    assert len(original) == N_HOSTS and all(len(v) == 6 for v in original.values())
    specs = {}
    for new, group in zip(sorted(chosen, key=lambda i: order("map-new", i["event"])),
                          sorted(original, key=lambda g: order("map-old", g)), strict=True):
        for key, t in original[group].items():
            token = order("blind-case", key)[:20]
            specs[token] = dict(event=new["event"], original_case=key, original_group=group,
                                components=t["components"], parts=t["parts"], tolerance_bins=t["tolerance_bins"])
    write(args.out / "hosts.json", sorted(chosen, key=lambda h: h["event"]))
    write(args.out / "designs.json", specs)
    write(args.out / "original-seal.json", read(old / "blind/seal.json"))


def waveform(freq, ntime, phases_bins, p):
    """Analytic per-bin integrals on the recorded clock, independent of the fitter."""
    log_coord = np.log(freq / 600.0) / 0.3
    center = p["center_mhz"]
    sigma_z = max(.07, p["effective_bandwidth_mhz"] / (2 * np.sqrt(np.pi) * .3 * center))
    spectrum = np.exp(-.5 * ((log_coord - np.log(center / 600) / .3) / sigma_z) ** 2)
    dispersion = (freq ** -2 - 600.0 ** -2) / np.ptp(freq ** -2)
    arrival = p["arrival"] + p["dm_span_bins"] * dispersion
    edge = (np.arange(ntime + 1) - .5 + phases_bins[:, None]) - arrival[:, None]
    sigma = p["sigma"]
    if p["tau"] == 0:
        cdf = ndtr(edge / sigma)
    else:
        tau = p["tau"] * (freq / 600) ** p["scatter_index"]
        cdf = exponnorm.cdf(edge, K=tau[:, None] / sigma, scale=sigma)
    profile = np.diff(cdf, axis=1)
    assert np.isfinite(profile).all() and profile.min() >= -1e-12
    return spectrum[:, None] * np.maximum(profile, 0)


def generate(args):
    hosts = read(args.out / "hosts.json")
    specs = read(args.out / "designs.json")
    local = {p.stem: p for location in args.h5 for p in location.glob("*.h5") if p.stem.isdecimal()}
    by_event = defaultdict(list)
    for key, spec in specs.items():
        by_event[spec["event"]].append((key, spec))
    for mode in ("shared", "measured"):
        (args.out / mode / "inputs").mkdir(parents=True, exist_ok=True)
    manifest, truth = {}, {}
    for host in hosts:
        event, start = host["event"], host["start"]
        path = local[event] if event in local else next(folder / host["product"] for folder in args.h5
                                                        if (folder / host["product"]).exists())
        assert digest(path) == host["product_sha256"]
        raw, grid, freq, phases, err = open_native(path, event)
        assert abs(err - host["timestamp_error_bins"]) < .00001
        grid.update(num_freq=len(freq), num_time=CROP, times_bin0=grid["times_bin0"] + start * grid["res_time"])
        ids = np.array(host["channels"], dtype=int)
        noise = np.zeros((len(freq), CROP))
        noise[ids] = raw[ids, start:start+CROP]
        sd = np.std(noise[ids], axis=1, ddof=1)
        sd = np.maximum(sd, .1 * np.median(sd))
        for key, spec in sorted(by_event[event]):
            signal = np.zeros_like(noise)
            for i, p in enumerate(spec["parts"]):
                profile = waveform(freq, CROP, phases / grid["res_time"], p)
                white = profile[ids] / sd[:, None]
                if i == 0:
                    snr = np.linalg.norm(white.sum(axis=0) / np.sqrt(len(ids)))
                    strength = p["profile_snr"]
                else:
                    snr = np.linalg.norm(white - white.mean(axis=1, keepdims=True))
                    strength = p["nominal_snr"]
                assert np.isfinite(snr) and snr > 1e-12
                signal[ids] += profile[ids] * (strength / snr)
            y = noise + signal
            envelope = signal[ids].max(axis=0)
            on = np.flatnonzero(envelope >= .01 * envelope.max())
            truth[key] = dict(arrival_bins=[p["arrival"] for p in spec["parts"]],
                              on_window=[int(on[0]), int(on[-1]) + 1], tolerance_bins=spec["tolerance_bins"],
                              event=event, dt=grid["res_time"])
            vals = dict(data_full=y, metadata=np.array(json.dumps(grid, sort_keys=True)))
            checksums = {}
            for mode, extra in [("shared", {}), ("measured", {"channel_time_offset_s": phases})]:
                dest = args.out / mode / "inputs" / (key + ".npz")
                np.savez(dest, **vals, **extra)
                checksums[mode] = digest(dest)
            manifest[key] = checksums
    assert len(manifest) == 780
    write(args.out / "truth.json", truth)
    write(args.out / "input-manifest.json", manifest)
    write(args.out / "seal.json", {name: digest(args.out / name) for name in
                                   ("hosts.json", "designs.json", "truth.json", "input-manifest.json",
                                    "prepare.py", "PROTOCOL.md", "original-seal.json")})
    print("Sealed", len(manifest), "paired inputs", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=["select", "generate"])
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--study", type=Path)
    parser.add_argument("--atlas", type=Path)
    parser.add_argument("--h5", type=Path, nargs="+", required=True)
    args = parser.parse_args()
    (select if args.stage == "select" else generate)(args)
