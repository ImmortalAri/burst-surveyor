"""Score all verified paired exports using the frozen split and arrival criteria."""
import argparse
import csv
import hashlib
import json
from collections import Counter
from itertools import permutations
from pathlib import Path

import numpy as np


ARMS = ("shared", "measured")


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load_run(root, arm, manifest):
    run = root / arm / "run"
    verified = read(root / arm / "verified.json")
    batch = read(run / "results.json")
    method = read(run / "manifest.json")["method"]
    assert method["product_version"] == "0.2.0" and method["policy"]["mode"] == "bounded"
    assert verified["inputs"] == batch["inputs"] == len(batch["events"]) == len(manifest)
    assert verified["exported"] == batch["exported"]
    events = {Path(row["input_name"]).stem: row for row in batch["events"]}
    assert events.keys() == manifest.keys()
    for case, row in events.items():
        assert row["source_sha256"] == manifest[case][arm]
    return events, method, dict(statuses=verified["statuses"], exported=verified["exported"],
                                sha256={f: digest(run / f) for f in ("manifest.json", "seal.json", "results.json")})


def metrics(root, arm, event, truth):
    run = root / arm / "run"
    primary = read(run / event["primary_receipt"])
    native = read(run / event["native_receipt"])
    assert native["source_sha256"] == primary["source_sha256"] == event["source_sha256"]
    targets = truth["arrival_bins"]
    tol = truth["tolerance_bins"]
    usable = native["status"] == "provisional" and native.get("selected") is not None
    count = (primary.get("selected") or {}).get("n", 0)
    arrivals = []
    if usable:
        pars = native["fitburst_parameters"]
        arrivals = [x / truth["dt"] for x in pars["arrival_time"]]
        assert len(arrivals) == count and all(f == 600 for f in pars["ref_freq"])
        np.testing.assert_allclose(arrivals, native["selected"]["x"][1:count*5:5], rtol=1e-12, atol=1e-12)
        assert (native.get("time_grid") == "per-channel constant offsets") == (arm == "measured")
    if len(targets) == 1:
        hit = count >= 2
    else:
        assert len(targets) == 2 and abs(tol - min(2., .45 * abs(targets[0] - targets[1]))) < 1e-10
        hit = usable and any(abs(a-targets[0]) <= tol and abs(b-targets[1]) <= tol for a, b in permutations(arrivals, 2))
    info = dict(status=native["status"], count=count, usable=usable, fitted_bins=arrivals, outcome=int(hit))
    return info, (run / event["prediction"] if usable else None)


def on_pulse_errors(measured_input, paths, on):
    """Fit pair on identical rows with fixed weights, times and off-pulse baseline rule."""
    with np.load(measured_input) as obs, np.load(paths["shared"]) as shared, np.load(paths["measured"]) as measured:
        for k in ("channels", "channel_mask", "offburst_time_mask", "variance", "frequency", "time_s", "res_time"):
            np.testing.assert_equal(shared[k], measured[k])
        np.testing.assert_allclose(obs["channel_time_offset_s"], measured["channel_time_offset_s"], rtol=2e-15, atol=0)
        assert "channel_time_offset_s" not in shared
        ids = shared["channels"]
        var = shared["variance"][ids]
        off = shared["offburst_time_mask"]
        y = obs["data_full"][ids]
        assert (var > 0).all() and np.isfinite(var).all() and off.any()
        powers = []
        for pred in (shared, measured):
            residual = y - pred["prediction"][ids]
            residual -= residual[:, off].mean(axis=1, keepdims=True)
            wrss = np.sum(residual[:, on[0]:on[1]] ** 2 / var[:, None])
            assert wrss > 0 and np.isfinite(wrss)
            powers.append(float(wrss))
    return powers


def compare(rows, n, hosts, draws):
    sub = [r for r in rows if r["injected"] == n]
    a = np.array([r["shared_outcome"] for r in sub])
    b = np.array([r["measured_outcome"] for r in sub])
    per = Counter()
    assignment = Counter()
    for r, delta in zip(sub, b-a, strict=True):
        per[r["event_id"]] += int(delta)
        assignment[r["event_id"]] += 1
    assert len(assignment) == len(hosts) and set(assignment.values()) == {2 if n == 1 else 4}
    diff = np.array([per[e] / assignment[e] for e in hosts])
    assert np.isclose(diff.mean(), b.mean() - a.mean())
    bounds = np.quantile(100 * diff[draws].mean(axis=1), [.025,.975])
    return dict(trials=len(sub), shared=int(a.sum()), measured=int(b.sum()), both_yes=int((a & b).sum()),
                neither=int(((a == 0) & (b == 0)).sum()),
                shared_only=int(((a == 1) & (b == 0)).sum()), measured_only=int(((a == 0) & (b == 1)).sum()),
                delta_percentage_points=float(100 * diff.mean()), cluster_bootstrap_95_pp=bounds.tolist())


def score(root):
    seal = read(root / "seal.json")
    for filename, sha in seal.items():
        assert digest(root / filename) == sha
    manifest = read(root / "input-manifest.json")
    truth = read(root / "truth.json")
    specs = read(root / "designs.json")
    assert manifest.keys() == truth.keys() == specs.keys()
    runs, methods, provenance = {}, {}, {}
    for arm in ARMS:
        runs[arm], methods[arm], provenance[arm] = load_run(root, arm, manifest)
    assert methods["shared"] == methods["measured"]
    rows, changes = [], []
    for case, t in sorted(truth.items()):
        row = dict(case=case, event_id=t["event"], original_design=specs[case]["original_case"],
                   injected=len(t["arrival_bins"]), truth_arrivals_bins=json.dumps(t["arrival_bins"]),
                   tolerance_bins=t["tolerance_bins"], on_first_bin=t["on_window"][0], on_stop_bin=t["on_window"][1])
        paths = {}
        for arm in ARMS:
            stats, paths[arm] = metrics(root, arm, runs[arm][case], t)
            for k, v in stats.items():
                row[arm + "_" + k] = json.dumps(v) if isinstance(v, list) else v
        power = [None, None]
        if all(paths.values()):
            power = on_pulse_errors(root / "measured/inputs" / (case + ".npz"), paths, t["on_window"])
            changes.append(100 * (1 - power[1] / power[0]))
        for arm, val in zip(ARMS, power, strict=True):
            row[arm + "_on_wrss"] = val
        rows.append(row)
    out = root / "paired-results.csv"
    with out.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    hosts = sorted({t["event"] for t in truth.values()})
    assert len(hosts) == 130 and len(rows) == 780
    draws = np.random.default_rng(230211).integers(len(hosts), size=(20000, len(hosts)))
    result = dict(fitter="Burst Surveyor v0.2.0, bounded", fitburst=methods["shared"]["packages"]["fitburst"],
                  python=methods["shared"]["python"], packages=methods["shared"]["packages"],
                  noise_sources=len(hosts), cases=len(rows), runs=provenance,
                  single_splits=compare(rows, 1, hosts, draws), pairs_recovered=compare(rows, 2, hosts, draws),
                  on_pulse=dict(joint_exports=len(changes), lower_measured=sum(x > 0 for x in changes),
                                equal=sum(x == 0 for x in changes), median_reduction_pct=float(np.median(changes))),
                  input_seal_sha256=digest(root / "seal.json"), paired_results_sha256=digest(out))
    dest = root / "results-summary.json"
    dest.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(dest.read_text())


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    score(parser.parse_args().root)
